Te = in[0];
// Ub = in[1];
// Uc = in[2];
// Ia = in[3];
// Ib = in[4];
// Ic = in[5];
// wm = in[6];
// wm = in[7];
// Ud = in[8];


/*
// poslizg
(v == 0) ? v = 0.0001 : v = v;
slip = (r_0*w_w - v)/v;	

m_dyn = m_stc + (J_m*eta*n_g*n_g + J_w)/((1-slip)*(1-slip)*r_0*r_0);

// opory tarcia
F_roll = k0 + k1*v;	// opory od tarcia na przekladniach, lozyskach itd;

// opor aerodyamiczny
F_aero = 0.5 * ro_air * C_d * A_v * v*v;	// sila oporu powietrza

// opor w ruchu pod gore
F_grad = m_dyn*g*atan(fi_g*PI/180);	

// opor w ruchu na zakrecie
F_crv = 0;	 

// suma oporow ruchu
F_R = F_roll + F_aero + F_grad + F_crv;

// wspolczynnik przyczepnosci
slip_curve(slip*v, &mi);

F_a = mi*m_stc*g*l;

// rownanie ruchu pociagu
//F_tau = n_g*eta*2*Te/r_0; 
v += (1/(m_dyn)) * (F_a - F_R) * delt;

// rownanie dynamiki na kole
w_w += (1/(J_eqv*n_g)) * (Te - Bm*w_w - F_a*r_0/n_g) * delt;
*/

// nideokonczony model 
// https://link.springer.com/article/10.1007/s40534-018-0158-x
//
// [...]
//
// zbey mozna bylo liczyc poslizg, trzeba estymowac predkosc liniowa
v += (1/m_dyn) * (F_a - F_l) * delt;

// poslizg
slip = (w_lk*r_0 - v)/v;	

// wspolczynnik przyczepnosci
slip_curve(slip*v, &mi);

// sila przyczepnosci
F_al = m_b * g * mi;	// m_b = 17*1000;
F_ar = m_b * g * mi;

// moment przyczepnosci
T_al = F_al *r_0;
T_ar = F_ar *r_0;

// predkosc lewego kola
w_lk += (1/J_wl) * (T_wl - T_al) * delt;
theta_wl += w_lk * delt;
T_wl = K_k * ((theta_m/n_g) - theta_wl) + B_k * ((w_m/n_g) - w_lk);

// predkosc prawego kola
w_rk += (1/(J_wr + J_br + J_x)) * (T_wr - T_ar) * delt;
theta_wr += w_rk * delt;
T_wr = K_k * ((theta_m/n_g) - theta_wr) + B_k * ((w_m/n_g) - w_lr);

// transmisja momentu z silnika na wal
T_t = (1/n_g)*((J_g/n_g * dw_m) + T_wr + T_wl);


// rownanie ruchu na silnik, docelowo ma byc z inputa
T_e = 100;
w_m += (1/(J_m)) * (T_e - T_t) * delt;
dw_m = (w_m-w_m_old)/delt;
theta_m += w_m * delt;
w_m_old = w_m;



out[0] = v;
out[1] = w_w;
out[2] = slip;
out[3] = J_eqv;
out[4] = m_stc;
out[5] = F_tau;
out[6] = F_a;
out[7] = F_R;
out[8] = mi;//m_dyn;
out[9] = 0.0;
out[10] = 0.0;
out[11] = 0.0;
out[12] = 0.0;
out[13] = 0.0;
out[14] = 0.0;
out[15] = 0.0;


/*
J_eqv = 37.6;
r_0 = 0.5;
Bm = 0.32;
m_stc = 20*1000;
C_d = 0.63;
mi = (0.3/0.331) * 7.5/(44 + 3.6*v) + 0.161;
F_tau = mi*m_stc*g;
w_w += (1/J_eqv) * (Te - F_tau*r_0 - Bm*w_w) * delt;
v += (1/m_stc) * (F_tau - C_d*v*v) * delt;
(v == 0) ? v = 0.0001 : v = v;
slip = (r_0*w_w - v)/v;	
*/