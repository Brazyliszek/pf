	freqRef = in[0];
	pwmWave = in[1];
	curr_rms = in[2];
	
	// zabezpieczneie przed zwarciem
	if (freqRef > 0) {pwmEnabled = 1;}
	else { pwmEnabled = 0;}

	// rampa napiecia
	//if (freqRamp < freqRef) {freqRamp = freqRamp + rampF/rampT * delt;}
	//else if (freqRamp > freqRef ) {freqRamp = freqRamp - rampF/rampT * delt;}
	//else {freqRamp = freqRef;}	

	// pomijamy rampe i zadajemy bezposrednio freq
	if ((t > 0.5) && (t <= 5.5)){
		dir = 1;
		freqRamp = freqRamp + 10*delt;
		duty_vf = freqRamp/f_n;
	}
	else if ((t > 5.5) && (t <= 6.5)){
		freqRamp = 50.0;
		duty_vf = 1.0;
	}
	else if ((t > time_check) && (t <= time_check+0.2)){
		freqRamp = f_max;
		PIcurr_fbk = curr_rms;
		PIcurr_err = PIcurr_ref - PIcurr_fbk;
		PIcurrInt_err += PIcurr_Ki*PIcurr_err;
		PIcurr_out = PIcurr_Kp*PIcurr_err + PIcurrInt_err;
		if (PIcurr_out > 0.2) { PIcurr_out = 0.2;}
		if (PIcurr_out < 0.01) { PIcurr_out = 0.01;}
		duty_detected = PIcurr_out*freqRamp/f_max;
		duty_vf = duty_detected;
	}
	else if ((t > time_check+0.2) && (t < time_check+0.2+rampT)){
		dir = 1;
		freqRamp = freqRamp - f_max*delt/rampT;
		duty_vf = duty_detected*freqRamp/f_max;
	}
	else {
		freqRamp = 0.0;
		duty_vf = freqRamp/f_n;
	}

	// charakterystyka u/f
	freq_vf = freqRamp;

	// ograniczenie charakterystyki
	if (freq_vf <= f_min){ freq_vf = f_min;}
	if (freq_vf >= f_max){ freq_vf = f_max;}
	if (duty_vf <= duty_min){ duty_vf = duty_min;}
	if (duty_vf >= duty_max){ duty_vf = duty_max;}

	// wyznaczenie napiec 
	theta = theta + DWAPI*freq_vf*delt;
	voltageA = duty_vf*sin(theta + 0);
	voltageB = duty_vf*sin(theta  - dir*DWAPI/3);
	voltageC = duty_vf*sin(theta + dir*DWAPI/3);

	if (voltageA > pwmWave) {pwmA = 1;}
	else { pwmA = 0;}
	if (voltageB > pwmWave) {pwmB = 1;}
	else { pwmB = 0;}
	if (voltageC > pwmWave) {pwmC = 1;}
	else { pwmC = 0;}

	out[0]= 320*voltageA;
	out[1]= 320* voltageB;
	out[2]= 320* voltageC;
	out[3] = freq_vf;
	out[4] = theta;
	out[5] = duty_vf;