PI = 3.14159265359;
DWAPI = 2*PI;
PI120 = DWAPI/3;
SQRT3 = 1.73205080757;
halfSQRT3 = SQRT3/2;
invSQRT3 = 1/SQRT3;
SQRT23 = 0.81649658092;


Rs = 0.294;
Ls = 1.39 * 0.001;
Lm = 41 * 0.001;
Rr = 0.156;	//+ Lm;
Lr = 0.74 * 0.001;	// + Lm;
Pb = 3.0;
J = 0.4;
fn = 50;
D = (1 - (Lm*Lm/(Lr*Ls)));
Tn = 1/(DWAPI*fn);


Us_alfa = 0.0;
Us_beta = 0.0;
Is_alfa = 0.0;
Is_beta = 0.0;
dIs_alfa = 0.0;
dIs_beta = 0.0;
Is_alfa_old = 0.0;
Is_beta_old = 0.0;
dPsiR_alfa = 0.0;
dPsiR_beta = 0.0;
PsiR_alfa_old = 0.0;
PsiR_beta_old = 0.0;

Is_error_alfa = 0.0;
Is_error_beta = 0.0;
wm_est_PI_input = 0.0;
wm_est_PI_int = 0.0;
wm_est_PI_output = 0.0;
wm_est_PI_kp = 0.0001;
wm_est_PI_ki = 0.001; 



wm = 0.0;
wm_est = 0.0;
wm_est2 = 0.0;
Te = 0.0;
Tm = 0.0;
theta = 0.0;