PI = 3.14159265359;
DWAPI = 2*PI;
PI120 = DWAPI/3;
SQRT3 = 1.73205080757;
halfSQRT3 = SQRT3/2;
invSQRT3 = 1/SQRT3;
SQRT23 = 0.81649658092;

/*~~ zerowanie zmiennych ~~*/
F_tau = 0.0;		// sila trakcyjna
F_R = 0.0;	// suma sil oporowych
F_roll = 0.0;	// sila toczenia sie skladu
F_aero = 0.0;	// sila oporu aerodynamicznego
F_grad = 0.0;	// sila grawitacji przy wznosie
F_crv = 0.0;	// sila oporu zakret
v = 0.0;	// predkosc liniowa
mi = 0.0;		// wspolczynnik przyczeponosci
F_a = 0.0;		// sila przyczeponosci
slip = 0.0;		// poslizg
w_w = 0.0;		// predkosc na kole
m_dyn = 0.0;		// moment bezwladnosci calkowity mas wirujacych i mas niewirujacych

/*~~ wspolczynniki zwiazane konstrukcja pociagu ~~*/
eta = 0.98;	// sprawnosc przekladni
n_g = 6.92;	// przelozenie przekladni
r_0 = 0.920/2;	// promien kola 
r_r = 0.1;	// srednica walu silnika [m]
l = 4;	// ilosc zestawow trakcyjnych
n = 2;	// ilosc kol na jednym wozku
m = 4;	// ilosc wozkow

/*~~ wspolczynniki zwiazane z masa ~~*/
m_pass = 20*1000;		// masa pasazerow
m_vb = 32*1000;		// masa pociagu
m_motor = 180;	// masa calkowita silnika
m_r = 120;	// masa wirnika	[kg]
m_w = 214;	// masa kola [kg]
m_x = 157;	// masa osi
m_br = 57;	// masa ukladu hamowania
m_g = 60;	// masa przekladni
m_b = 2500;	// masa wozka
m_stc = m_pass + m_vb + n*m*(2*m_w + m_x + m_br) + m*m_b + l*(m_motor + m_g);	// masa calkowita

/*~~ wspolczynniki zwiazane z bezwladnosciami ~~*/
J_g = 0.014;	// moment bezwladnosci przekladni
J_br = 0.0022;	// moment bezwladnosci systemu hamulcowego
J_x = 9.0746;	// moment bezwladnosci osi
J_m = 0.5*m_r*r_r*r_r*l;	// moment bezwladnosci silnikow
J_w = m_w*r_0*r_0*n*m;	// moment bezwladnosci lewego i prawego kola
J_eqv = J_m + J_g + (J_w + J_br + J_x)/(n_g*n_g);	// moment zastepczy

/*~~ wspolczynniki zwiazane z mechanika ~~*/
k0 = 1203.4;	// wspolczynnik do oporu tarcie mechanicznego
k1 = 21.91; 	// wspolczynnik do oporu tarcie mechanicznego
Bm = 2;	// wspolczynnik tarcia wiskotycznego

/*~~ wspolczynniki zwiazane z powietrzem i ksztaltem ~~*/
A_v = 9;	// powierzchnia czoła	[m^2]
ro_air = 1.2;	// gestosc powietrza (1.2 suche 20oC);
C_d = 0.8;	// zalezy od ksztaltu czola, 0.5 dla kola, 0.1 dla skrzydla, 1.0 dla plaskiego

/*~~ wspolczynniki zwiazane z droga i srodowiskiem ~~*/
fi_g = 0;	// nachylenie wzniesienia w stopniach
alfa1 = 0.4048;	// wspolczynniki przyczeponosci Burckhardt model (Kiencke & Nielsen, 2000)
alfa2 = 2.0148;	// wspolczynniki przyczeponosci Burckhardt model (Kiencke & Nielsen, 2000)
alfa3 = 0.0751;	// wspolczynniki przyczeponosci Burckhardt model (Kiencke & Nielsen, 2000)
g = 9.81;	// sila grawitacji