double Ua, Ub, Uc;
double Ia, Ib, Ic;
double Us_alfa, Us_beta;
double Is_alfa, Is_beta, Ir_alfa, Ir_beta;
double PsiS_est_alfa, PsiS_est_beta, PsiS_est_theta, PsiS_est_mod;
double dIs_alfa, dIs_beta;
double Is_alfa_old, Is_beta_old;
double Is_est_alfa, Is_est_beta;
double wm, Te, Tm, Tn, fn, theta;
double Rs, Rr, Ls, Lr, Lm, Pb, J, Mo, D, Xr, Xs, Xm;
double PI, DWAPI, SQRT3, halfSQRT3, invSQRT3, SQRT23, PI120;
double flux_ref, me_ref, wm_ref;
double flux_integral, me_integral, wm_integral;
double flux_out, me_out, wm_out;
double me_est;
double Sa, Sb, Sc;
double SVM_alfa, SVM_beta, Udc;
double test_integral, test_out;
double T0, T1, T2;
double rad, mag, deg;
int sector;
double SVM_f, SVM_T, SVM_clk;
int TSa, TSb, TSc;
double pwmtheta, pwma, pwmb, pwmc;
double wmn, un, in, men, pn;


void lowpass(double input, double ratio, double *var){
	*var = (input + (*var)*(ratio-1))/ratio;
}


void abc2alfabeta(double a, double b, double c, double *pValAlfa, double *pValBeta){
	*pValAlfa = a;
	*pValBeta = invSQRT3*a + 2*invSQRT3*b; 
}

void xy2alfabeta(double x, double y, double theta, double *pValAlfa, double *pValBeta){
	*pValAlfa = x*cos(theta) - y*sin(theta);
	*pValBeta = x*sin(theta) + y*cos(theta); 
}

void alfabeta2xy(double alfa, double beta, double theta, double *pValX, double *pValY){
	*pValX = alfa*cos(theta) + beta*sin(theta);
	*pValY = -alfa*sin(theta) + beta*cos(theta); 
}

void alfabeta2abc(double alfa, double beta, double *pValA, double *pValB, double *pValC){
	*pValA = alfa;
	*pValB = (-0.5)*alfa + halfSQRT3*beta; 
	*pValC = (-0.5)*alfa - halfSQRT3*beta; 
}

void abc2xy(double a, double b, double c, double theta, double *pValX, double *pValY){
	*pValX = SQRT23*(a*cos(theta) + b*cos(theta - PI120) + c*cos(theta + PI120));
	*pValY = SQRT23*(-a*sin(theta) - b*sin(theta - PI120) - c*sin(theta + PI120));
}

void pi(double ref, double fbk, double kp, double ki, double min, double max, double *integral, double *out){
	double temp_out;
	*integral += ki*(ref-fbk);
	temp_out = kp*(ref-fbk) + *integral;
	if (temp_out > max){
		temp_out = max;
		*integral -= ki*(ref-fbk);
	}
	if (temp_out < min){
		temp_out = min;
		*integral -= ki*(ref-fbk);
	}
	*out = temp_out;
}

void rad2deg( double rad, double *deg){
	(rad < 0) ? rad += DWAPI : rad = rad;
	(rad > DWAPI) ? rad -= DWAPI : rad = rad;
	*deg = rad*180/PI;
}

void deg2rad( double deg, double *rad){
	(deg < 0) ? deg += 360 : deg = deg;
	(deg > 360) ? deg -= 360 : deg = deg;
	*rad = deg*PI/180;
}

void alfabeta2mag(double alfa, double beta, double *mag){
	*mag = sqrt(alfa*alfa + beta*beta);
}
void alfabeta2theta(double alfa, double beta, double *theta){
	*theta = atan2(SVM_beta, SVM_alfa);
}

void deg2sector( double deg, int *sector){
	if ((deg > 0) && (deg <= 60))
		*sector = 1;
	else if ((deg > 60) && (deg <= 120))
		*sector = 2;
	else if ((deg > 120) && (deg <= 180))
		*sector = 3;
	else if ((deg > 180) && (deg <= 240))
		*sector = 4;
	else if ((deg > 240) && (deg <= 300))
		*sector = 5;
	else
		*sector = 6;
}

void sector2driver(int sector, int *a, int *b, int*c){
	if (sector == 0){
		*a = 0;
		*b = 0;
		*c = 0;
	}
	if (sector == 1){
		*a = 1;
		*b = 0;
		*c = 0;
	}
	if (sector == 2){
		*a = 1;
		*b = 1;
		*c = 0;
	}
	if (sector == 3){
		*a = 0;
		*b = 1;
		*c = 0;
	}
	if (sector == 4){
		*a = 0;
		*b = 1;
		*c = 1;
	}
	if (sector == 5){
		*a = 0;
		*b = 0;
		*c = 1;
	}
	if (sector == 6){
		*a = 1;
		*b = 0;
		*c = 1;
	}
	if (sector == 7){
		*a = 1;
		*b = 0;
		*c = 0;
	}
}

	
