double Sa, Sb, Sc;
double Ia, Ib, Ic;
double PwmRefA, PwmRefB, PwmRefC;
double Ucd;
double wm; 
double PI, DWAPI, PI23 PI6, TS;
double theta;