Ua = in[0];
Ub = in[1];
Uc = in[2];
Ia = in[3];
Ib = in[4];
Ic = in[5];
wm = in[6];
wm_ref = in[7];
Udc = in[8];


// modele https://kener.elektr.polsl.pl/epedlab/lect.php?no=a3&l=en
// current estimator https://www.researchgate.net/publication/224586175_Stator-Current-Based_MRAS_Estimator_for_a_Wide_Range_Speed-Sensorless_Induction-Motor_Drive
// dybek universal speed and flux estimator https://pdfs.semanticscholar.org/3b78/c017a2d66ff11b1a16383824e4223bc21a8b.pdf


// transformacje
abc2alfabeta(Ua, Ub, Uc, &Us_alfa, &Us_beta);
abc2alfabeta(Ia, Ib, Ic, &Is_alfa, &Is_beta);

// estymacja strumienia
PsiS_est_alfa += (0.67*Udc*SVM_alfa - Rs*Is_alfa)*delt;
PsiS_est_beta += (0.67*Udc*SVM_beta - Rs*Is_beta)*delt;
PsiS_est_theta = atan2(PsiS_est_beta, PsiS_est_alfa);
PsiS_est_mod = sqrt(PsiS_est_alfa*PsiS_est_alfa + PsiS_est_beta*PsiS_est_beta);

// estymator momentu
me_est = Pb*(PsiS_est_alfa*Is_beta - PsiS_est_beta*Is_alfa);
//lowpass(me_est, 150, &me_est);


// regulator predkosci
pi(wm_ref, wm/wmn, 1, 0.001, -1, 1, &wm_integral, &wm_out);

// regulator strumienia
flux_ref = 0.9;
pi(flux_ref, PsiS_est_mod, 0.4, 0.1, -1, 1, &flux_integral, &flux_out);

// regulator momentu
me_ref = wm_out;
pi(me_ref, me_est/men, 2, 0.1, -1, 1, &me_integral, &me_out);

// wyjscie
xy2alfabeta(flux_out, me_out, PsiS_est_theta, &SVM_alfa, &SVM_beta);
//alfabeta2abc(SVM_alfa, SVM_beta, &Sa, &Sb, &Sc);


// Space vector modulator
SVM_f = 2000;
SVM_T = 1/SVM_f;
SVM_clk += delt;
if (SVM_clk >= SVM_T){
	SVM_clk = 0.0;
	alfabeta2mag(SVM_alfa, SVM_beta, &mag);
	alfabeta2theta(SVM_alfa, SVM_beta, &rad);
	rad += PI/2;
	rad2deg(rad, &deg);
	deg2sector(deg, &sector);
	mag = mag;
	(mag < 0) ? mag = 0.0 : mag = mag;
	(mag > 1) ? mag = 1.0 : mag = mag;
	T0 = SVM_T*(1-mag);
	T1 = T0 + SVM_T*(mag*(sector*60-deg)/60);
	T2 = T1 + SVM_T*(mag*(deg-(sector-1)*60)/60);
}

if (SVM_clk < T0)
	sector2driver(0, &TSa, &TSb, &TSc);
else if ((SVM_clk >= T0) && (SVM_clk < T1))
	sector2driver(sector, &TSa, &TSb, &TSc);
else
	sector2driver(sector + 1, &TSa, &TSb, &TSc);


out[0] = TSa;
out[1] = TSb;
out[2] = TSc;
out[3] = flux_ref;
out[4] = PsiS_est_mod;
out[5] = me_ref;
out[6] = me_est/men;
out[7] = wm_ref;
out[8] = wm/wmn;
out[9] = 0.0;
out[10] = 0.0;
out[11] = 0.0;
out[12] = 0.0;
out[13] = 0.0;
out[14] = 0.0;
out[15] = 0.0;

