void abc2alfabeta(double a, double b, double c, int *pValAlfa, int *pValBeta){
	*pValAlfa = 3.0; //(2/3)*(a - 0.5*b - 0.5*c);
	*pValBeta = 4.0; //(2/3)*(halfSQRT3*b - halfSQRT3*c); 
}

