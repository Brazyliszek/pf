PI = 3.14159265359;
DWAPI = 2*PI;
PI23 = PI*2/3;
PI6 = PI/6;
TS = 0.0001;

theta = 0.0;