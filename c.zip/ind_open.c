	pwmEnabled = 0;
	freqRamp = 0.0;
	rampF = 50;	// ramp frequency in herzs
	rampT = 2.5;	// ramp time in seconds
	u_n = 150;	// nominal voltage dc link
	f_n = 50;		// nominal frequency at the output of inverter
	f_min = 0;
	f_max = 87;
	duty_min = 0.0;
	duty_max = 1.0;
	dir = 1;
	time_check = 8.0;
	duty_detected = 0.1;
	
	PIcurr_ref = 5.0;
	PIcurr_Kp = 0.001;
	PIcurr_Ki = 0.00001;
	PIcurr_out = 0;