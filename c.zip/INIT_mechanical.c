/*
Model opracowano na podstawie:
Modeling, simulation and slip control of a railway
vehicle integrated with traction power supply
Caglar Uyulan

Metin Gokasan and Seta Bogosyan
 
https://www.cogentoa.com/article/10.1080/23311916.2017.1312680.pdf
*/


double wm, Te, Tm, Tn, fn, theta;
double PI, DWAPI, SQRT3, halfSQRT3, invSQRT3, SQRT23, PI120;

double F_tau;		// sila trakcyjna
double F_R;	// suma sil oporowych
double F_roll;	// sila toczenia sie skladu
double F_aero;	// sila oporu aerodynamicznego
double F_grad;	// sila grawitacji przy wznosie
double F_crv;	// sila oporu zakret
double v;	// predkosc liniowa
double mi;		// wspolczynnik przyczeponosci
double F_a;		// sila przyczeponosci
double slip;		// poslizg
double w_w;		// predkosc na kole
double m_dyn;		// moment bezwladnosci calkowity mas wirujacych i mas niewirujacych

/*~~ wspolczynniki zwiazane konstrukcja pociagu ~~*/
double eta;	// sprawnosc przekladni
double n_g;	// przelozenie przekladni
double r_0;	// promien kola 
double r_r;	// srednica walu silnika [m]
double l;	// ilosc zestawow trakcyjnych
double n;	// ilosc kol na jednym wozku
double m;	// ilosc wozkow

/*~~ wspolczynniki zwiazane z masa ~~*/
double m_pass;		// masa pasazerow
double m_vb;		// masa pociagu
double m_motor;	// masa calkowita silnika
double m_r;	// masa wirnika	[kg]
double m_w;	// masa kola [kg]
double m_x;	// masa osi
double m_br;	// masa ukladu hamowania
double m_g;	// masa przekladni
double m_b;	// masa wozka
double m_stc;	// masa calkowita

/*~~ wspolczynniki zwiazane z bezwladnosciami ~~*/
double J_g;	// moment bezwladnosci przekladni
double J_br;	// moment bezwladnosci systemu hamulcowego
double J_x;	// moment bezwladnosci osi
double J_m;	// moment bezwladnosci silnikow
double J_w;	// moment bezwladnosci lewego i prawego kola
double J_eqv;	// moment zastepczy

/*~~ wspolczynniki zwiazane z mechanika ~~*/
double k0;	// wspolczynnik do oporu tarcie mechanicznego
double k1; 	// wspolczynnik do oporu tarcie mechanicznego
double Bm;	// wspolczynnik tarcia wiskotycznego

/*~~ wspolczynniki zwiazane z powietrzem i ksztaltem ~~*/
double A_v;	// powierzchnia czoła	[m^2]
double ro_air;	// gestosc powietrza (1.2 suche 20oC);
double C_d;	// zalezy od ksztaltu czola, 0.5 dla kola, 0.1 dla skrzydla, 1.0 dla plaskiego

/*~~ wspolczynniki zwiazane z droga i srodowiskiem ~~*/
double fi_g;	// nachylenie wzniesienia w stopniach
double alfa1;	// wspolczynniki przyczeponosci Burckhardt model (Kiencke & Nielsen, 2000)
double alfa2;	// wspolczynniki przyczeponosci Burckhardt model (Kiencke & Nielsen, 2000)
double alfa3;	// wspolczynniki przyczeponosci Burckhardt model (Kiencke & Nielsen, 2000)
double g;	// sila grawitacji

// slip in m/s
void slip_curve(double slip, double *mi){
	double slip_lin = 0.7;	// zakres liniowej zmiany wspolczynnika
	double mi_max = 0.4;	// maksyhmalna wartosc wspolczynnika
	if (slip == 0) 
		*mi = 0;
	else
		*mi = 2*mi_max/((slip/slip_lin) + (slip_lin/slip));
}

void rad2deg( double rad, double *deg){
	(rad < 0) ? rad += DWAPI : rad = rad;
	(rad > DWAPI) ? rad -= DWAPI : rad = rad;
	*deg = rad*180/PI;
}

void deg2rad( double deg, double *rad){
	(deg < 0) ? deg += 360 : deg = deg;
	(deg > 360) ? deg -= 360 : deg = deg;
	*rad = deg*PI/180;
}


double absf(double val){
	(val < 0) ? val = (-1)*val : val = val;
	return val;
}