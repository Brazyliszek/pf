Ua = in[0];
Ub = in[1];
Uc = in[2];
Ia = in[3];
Ib = in[4];
Ic = in[5];
wm = in[6];


// modele https://kener.elektr.polsl.pl/epedlab/lect.php?no=a3&l=en
// current estimator https://www.researchgate.net/publication/224586175_Stator-Current-Based_MRAS_Estimator_for_a_Wide_Range_Speed-Sensorless_Induction-Motor_Drive
// dybek universal speed and flux estimator https://pdfs.semanticscholar.org/3b78/c017a2d66ff11b1a16383824e4223bc21a8b.pdf


// transformacje
abc2alfabeta(Ua, Ub, Uc, &Us_alfa, &Us_beta);
abc2alfabeta(Ia, Ib, Ic, &Is_alfa, &Is_beta);


// pochodna pradu stojana
dIs_alfa = (Is_alfa - Is_alfa_old)/delt;
dIs_beta = (Is_beta - Is_beta_old)/delt;
Is_alfa_old = Is_alfa;
Is_beta_old = Is_beta;


// rotor flux estimator voltage based
PsiR_estU_alfa += (Lr/Lm)*(Us_alfa - Rs*Is_alfa - Ls*D*dIs_beta)*delt;
PsiR_estU_beta += (Lr/Lm)*(Us_beta - Rs*Is_beta - Ls*D*dIs_alfa)*delt;

PsiR_estU_theta = atan2(PsiR_estU_beta, PsiR_estU_alfa);	// calculating theta from voltage-based estimator
// PsiR_estU_theta += PI;
// (PsiR_estU_theta) ? PsiR_estU_theta += DWAPI : PsiR_estU_theta = PsiR_estU_theta;
// (PsiR_estU_theta > DWAPI) ? PsiR_estU_theta -= DWAPI : PsiR_estU_theta = PsiR_estU_theta;


// rotor flux estimator current based
PsiR_estI_alfa += (Rr/Lr)*(Lm*Is_alfa - PsiR_estI_alfa + (Lr/Rr)*wm_est*PsiR_estI_beta)*delt;
PsiR_estI_beta += (Rr/Lr)*(Lm*Is_beta - PsiR_estI_beta - (Lr/Rr)*wm_est*PsiR_estI_alfa)*delt;
 
PsiR_estI_theta = atan2(PsiR_estI_alfa, PsiR_estI_beta);	// calculating theta from current-based estimator
// PsiR_estI_theta += PI;
// (PsiR_estI_theta < 0) ? PsiR_estI_theta += DWAPI : PsiR_estI_theta = PsiR_estI_theta;
// (PsiR_estI_theta > DWAPI) ? PsiR_estI_theta -= DWAPI : PsiR_estI_theta = PsiR_estI_theta;


// estymator pradu stojana
Is_est_alfa += ((Is_est_alfa*(-1)*Tn*(Rr*Lm*Lm + Lr*Lr*Rs)/(D*Ls*Lr*Lr)) + (Us_alfa/(D*Ls)) + (PsiR_estI_alfa*Lm*Rr)/(D*Ls*Lr*Lr) + (PsiR_estU_beta*wm_est*Lm*Tn)/(D*Ls*Lr))*delt;
Is_est_beta += ((Is_est_beta*(-1)*Tn*(Rr*Lm*Lm + Lr*Lr*Rs)/(D*Ls*Lr*Lr)) + (Us_beta/(D*Ls)) + (PsiR_estI_beta*Lm*Rr)/(D*Ls*Lr*Lr) - (PsiR_estI_alfa*wm_est*Lm*Tn)/(D*Ls*Lr))*delt;


// estymator predkosci (Orlowska wyklad 15, slajd 23)
PsiR_estSelected_alfa = PsiR_estI_alfa;			// wybor estymatora strumienia - pradowy czy napieciowy
PsiR_estSelected_beta = PsiR_estI_beta;
dPsiR_alfa = (PsiR_estSelected_alfa - PsiR_alfa_old)/delt;
dPsiR_beta = (PsiR_estSelected_beta - PsiR_beta_old)/delt;
PsiR_alfa_old = PsiR_estSelected_alfa;
PsiR_beta_old = PsiR_estSelected_beta;
PsiR_mod = PsiR_estSelected_alfa*PsiR_estSelected_alfa + PsiR_estSelected_beta*PsiR_estSelected_beta;
(PsiR_mod == 0) ? PsiR_mod = 0.1 : PsiR_mod = PsiR_mod;
w_psiR = (PsiR_estSelected_alfa*dPsiR_beta - PsiR_estSelected_beta*dPsiR_alfa)/PsiR_mod;	// pulsacja strumienia wirnika
wm_est2 = (w_psiR-((Lm*Rr/Lr)*(Is_beta*PsiR_estSelected_alfa - Is_alfa*PsiR_estSelected_beta)/PsiR_mod));


// estymator predkosci dybek
Is_error_alfa = Is_alfa - Is_est_alfa;
Is_error_beta = Is_beta - Is_est_beta;
wm_est_PI_input = PsiR_estI_beta*Is_est_beta - PsiR_estI_alfa*Is_error_alfa;
wm_est_PI_int += wm_est_PI_ki*wm_est_PI_input;
wm_est_PI_output = wm_est_PI_kp*wm_est_PI_input + wm_est_PI_int;
wm_est = wm_est_PI_output;



out[0] = PsiR_estU_alfa;
out[1] = PsiR_estU_beta;
out[2] = PsiR_estU_theta;
out[3] = PsiR_estI_alfa;
out[4] = PsiR_estI_beta;
out[5] = PsiR_estI_theta;
out[6] = wm_est;
out[7] = Is_alfa;
out[8] = Is_beta;
out[9] = Is_est_alfa;
out[10] = Is_est_beta;
out[11] = wm_est2;
out[12] = 0.0;
out[13] = 0.0;
out[14] = 0.0;
out[15] = 0.0;

