rpm = in[0];
// Ub = in[1];
// Uc = in[2];
// Ia = in[3];
// Ib = in[4];
// Ic = in[5];
// wm = in[6];
// wm = in[7];
// Ud = in[8];

wm = DWAPI*rpm/60;

J_eqv = 37.6;
r_0 = 0.5;
Bm = 0.32;
m_stc = 20*1000;
C_d = 0.63;


mo = F_tau*r_0 - Bm*wm;
v += (1/m_stc) * (F_tau - C_d*v*v) * delt;
(v == 0) ? v = 0.0001 : v = v;
slip = (r_0*wm/n_g - v)/v;
slip_curve(slip, &mi);
F_tau = mi*m_stc*g;

out[0] = v;
out[1] = wm;
out[2] = slip;
out[3] = mo/n_g;
out[4] = 0.0;
out[5] = 0.0;
out[6] = 0.0;
out[7] = 0.0;
out[8] = mi;
out[9] = 0.0;
out[10] = 0.0;
out[11] = 0.0;
out[12] = 0.0;
out[13] = 0.0;
out[14] = 0.0;
out[15] = 0.0;

