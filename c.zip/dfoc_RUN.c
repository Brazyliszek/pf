

/* MODULATOR SVM */
theta += DWAPI*50*TS;
(theta > DWAPI) ? theta -= DWAPI : theta = theta;

if ((theta >= 0*PI6) && (theta <= 1*PI6)){
	
}
else if ((theta > 1*PI6) && (theta <= 2*PI6)){
	
}
else if ((theta > 2*PI6) && (theta <= 3*PI6)){
	
}
else if ((theta > 3*PI6) && (theta <= 4*PI6)){
	
}
else if ((theta > 4*PI6) && (theta <= 5*PI6)){
	
}
else{
	
}


out[0] = Sa;
out[1] = Sb;
out[2] = Sc;
out[3] = 0.0;
out[4] = 0.0;
out[5] = 0.0;
out[6] = 0.0;
out[7] = 0.0;
out[8] = 0.0;
out[9] = 0.0;
out[10] = 0.0;
out[11] = 0.0;
out[12] = 0.0;
out[13] = 0.0;
out[14] = 0.0;
out[15] = 0.0;
