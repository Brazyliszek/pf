double Ua, Ub, Uc;
double Ia, Ib, Ic;
double Us_alfa, Us_beta;
double Is_alfa, Is_beta, Ir_alfa, Ir_beta;
double PsiR_estU_alfa, PsiR_estU_beta, PsiR_estU_theta;
double PsiR_estI_alfa, PsiR_estI_beta, PsiR_estI_theta;
double dPsiR_alfa, dPsiR_beta;
double PsiR_alfa_old, PsiR_beta_old;
double PsiR_estSelected_alfa, PsiR_estSelected_beta;
double dIs_alfa, dIs_beta;
double Is_alfa_old, Is_beta_old;
double Is_est_alfa, Is_est_beta;
double wm, Te, Tm, Tn, fn, theta;
double Rs, Rr, Ls, Lr, Lm, Pb, J, Mo, D, Xr, Xs, Xm;
double PI, DWAPI, SQRT3, halfSQRT3, invSQRT3, SQRT23, PI120;
double wm_est, wm_est2, w_psiR, PsiR_mod;
double Is_error_alfa, Is_error_beta, wm_est_PI_input, wm_est_PI_int, wm_est_PI_output, wm_est_PI_kp, wm_est_PI_ki;


void abc2alfabeta(double a, double b, double c, double *pValAlfa, double *pValBeta){
	*pValAlfa = a;
	*pValBeta = invSQRT3*a + 2*invSQRT3*b; 
}

void xy2alfabeta(double x, double y, double theta, double *pValAlfa, double *pValBeta){
	*pValAlfa = x*cos(theta) - y*sin(theta);
	*pValBeta = x*sin(theta) + y*cos(theta); 
}

void alfabeta2xy(double alfa, double beta, double theta, double *pValX, double *pValY){
	*pValX = alfa*cos(theta) + beta*sin(theta);
	*pValY = -alfa*sin(theta) + beta*cos(theta); 
}

void alfabeta2abc(double alfa, double beta, double *pValA, double *pValB, double *pValC){
	*pValA = alfa;
	*pValB = (-0.5)*alfa + halfSQRT3*beta; 
	*pValC = (-0.5)*alfa - halfSQRT3*beta; 
}

void abc2xy(double a, double b, double c, double theta, double *pValX, double *pValY){
	*pValX = SQRT23*(a*cos(theta) + b*cos(theta - PI120) + c*cos(theta + PI120));
	*pValY = SQRT23*(-a*sin(theta) - b*sin(theta - PI120) - c*sin(theta + PI120));
}

