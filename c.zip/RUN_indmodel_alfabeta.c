// https://github.com/keguigong/linear-induction-motor-model


Ua = in[0];
Ub = in[1];
Uc = in[2];
Tm = in[3];

abc2alfabeta(Ua, Ub, Uc, &Us_alfa, &Us_beta);

FluxS_alfa += (Us_alfa - Rs*Is_alfa)*delt;
FluxS_beta += (Us_beta - Rs*Is_beta)*delt;
FluxR_alfa += (-Rr*Ir_alfa -wm*FluxR_beta)*delt;
FluxR_beta += (-Rr*Ir_beta +wm*FluxR_alfa)*delt;

// (FluxS_alfa > 100) ? FluxS_alfa = 100 : FluxS_alfa = FluxS_alfa;
// (FluxS_alfa < -100) ? FluxS_alfa = -100 : FluxS_alfa = FluxS_alfa;
// (FluxS_beta > 100) ? FluxS_beta = 100 : FluxS_beta = FluxS_beta;
// (FluxS_beta < -100) ? FluxS_beta = -100 : FluxS_beta = FluxS_beta;
// (FluxR_alfa > 100) ? FluxR_alfa = 100 : FluxR_alfa = FluxR_alfa;
// (FluxR_alfa < -100) ? FluxR_alfa = -100 : FluxR_alfa = FluxR_alfa;
// (FluxR_beta > 100) ? FluxR_beta = 100 : FluxR_beta = FluxR_beta;
// (FluxR_beta < -100) ? FluxR_beta = -100 : FluxR_beta = FluxR_beta;

Is_alfa = (FluxS_alfa*Lr - FluxR_alfa*Lm)/D;
Is_beta = (FluxS_beta*Lr - FluxR_beta*Lm)/D;
Ir_alfa = (FluxR_alfa*Ls - FluxS_alfa*Lm)/D;
Ir_beta = (FluxR_beta*Ls - FluxS_beta*Lm)/D;


// dFluxS_alfa = (FluxS_alfa - FluxS_alfa_old)/delt;
// dFluxS_beta = (FluxS_beta - FluxS_beta_old)/delt;
// dFluxR_alfa = (FluxR_alfa - FluxR_alfa_old)/delt;
// dFluxR_beta = (FluxR_beta - FluxR_beta_old)/delt;

// FluxS_alfa_old = FluxS_alfa;
// FluxS_beta_old = FluxS_beta;
// FluxR_alfa_old = FluxR_alfa;
// FluxR_beta_old = FluxR_beta;

// Is_alfa = (Us_alfa - dFluxS_alfa)/Rs;
// Is_beta = (Us_beta - dFluxS_beta)/Rs;
// Ir_alfa = (-wm*FluxR_beta -dFluxR_alfa)/Rr;
// Ir_beta = (wm*FluxR_alfa -dFluxR_beta)/Rr;

// FluxS_alfa = Ls*Is_alfa + Lm*Ir_alfa;
// FluxS_beta = Ls*Is_beta + Lm*Ir_beta;
// FluxR_alfa = Lr*Ir_alfa + Lm*Is_alfa; 
// FluxR_beta = Lr*Ir_beta + Lm*Is_beta;


Te = Pb*(FluxS_alfa*Is_beta - FluxS_beta*Is_alfa);

wm += ((Te-Tm)/J)*delt;

out[0] = Us_alfa;
out[1] = Us_beta;
out[2] = Te;
out[3] = 60*wm/DWAPI;
out[4] = 0.0;
out[5] = 0.0;
out[6] = 0.0;
out[7] = 0.0;
out[8] = 0.0;
out[9] = 0.0;
out[10] = 0.0;
out[11] = 0.0;
out[12] = 0.0;
out[13] = 0.0;
out[14] = 0.0;
out[15] = 0.0;

